import '../styles/globals.css'
import '../styles/royal.css'
import '../styles/sameer.css'
import '../styles/bootstrap.css'
import Script from 'next/script'
import AOS from 'aos'
import { useEffect } from 'react'


function MyApp({ Component, pageProps }) {
  useEffect(() => {
    AOS.init()
  }, [])
  return (
    <>

      <Component {...pageProps} />
      <Script
        id='154'
        
        dangerouslySetInnerHTML={{
          __html: `
          var slider = tns({
            "container": "#autoplay",
            "items": 5,
            "speed": 300,
            "autoplay": true,
            "controls":false,
            "autoplayHoverPause": true,
            "autoplayTimeout": 2000,
            "swipeAngle": false,
            "autoplayText": [
              "",
              ""
            ],
          });`
        }}
      />
      <Script src="https://kit.fontawesome.com/aafded4f19.js" crossorigin="anonymous" />
      <Script strategy='beforeInteractive' src="https://cdnjs.cloudflare.com/ajax/libs/tiny-slider/2.9.2/min/tiny-slider.js" />
      <Script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous" />
      
      <Script id='11'
        strategy="afterInteractive"
        dangerouslySetInnerHTML={{
          __html: `
       document.addEventListener('DOMContentLoaded', function () {
        const swiper = new Swiper('.swiper-container', {
          loop: true,
          slidesPerView: 1,
          spaceBetween: 32,
          centeredSlides: true,
          autoplay: {
            delay: 8000,
          },
          breakpoints: {
            640: {
              slidesPerView: 1.5,
            },
            1024: {
              slidesPerView: 3,
            },
          },
        })
      })
     `,
        }}
      />
    </>
  )
}

export default MyApp
