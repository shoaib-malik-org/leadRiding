import Image from "next/image";
import img from '../img/testimonials-4.jpg'
import style from '../styles/Home.module.css'


export default function Tesiimonal() {
  return (
    <>
      <section className="bg-white">
        <div className="w-100 py-5 text-center bg-dorange mt-4">
          <h2 className="text-4xl font-bold tracking-tight sm:text-5xl">
            Read trusted reviews from our customers
          </h2>
          <p className="max-w-lg mx-auto mt-4 text-gring-offset-warm-gray-500">
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Aspernatur
            praesentium natus sapiente commodi.
          </p>
        </div>
        <div className="max-w-screen-xl px-4 py-16 mx-auto sm:px-6 lg:px-8 sm:py-24">

          <div className={`container-fluid position-relative`}>
            <div id="carouselExampleDark" class="carousel carousel-dark slide" data-bs-ride="carousel">
              <div class="carousel-indicators" style={{ bottom: '-70px' }}>
                <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="1" aria-label="Slide 2"></button>
                <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="2" aria-label="Slide 3"></button>
              </div>
              <div class="carousel-inner">
                <div class="carousel-item active" data-bs-interval="10000">
                  <div className="mt-5">
                    <Image
                      src={img.src}
                      height={'120px'}
                      width={'120px'}
                      className={`${style.testiImg}`}
                      alt={'photo'}
                    />
                    <h3 className="text-dark mt-3">
                      Matt Brandon
                    </h3>
                  </div>

                  <div className="w-75 ms-auto me-auto mt-5">
                    <p className="text-dark">
                      Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown
                    </p>
                  </div>

                </div>
                <div class="carousel-item" data-bs-interval="2000">
                  <div className="mt-5">
                    <Image
                      src={img.src}
                      height={'120px'}
                      width={'120px'}
                      className={`${style.testiImg}`}
                      alt={'photo'}
                    />
                    <h3 className="text-dark mt-3">
                      Matt Brandon
                    </h3>
                  </div>

                  <div className="w-75 ms-auto me-auto mt-5">
                    <p className="text-dark">
                      Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown
                    </p>
                  </div>


                </div>
                <div class="carousel-item">
                  <div className="mt-5">
                    <Image
                      src={img.src}
                      height={'120px'}
                      width={'120px'}
                      className={`${style.testiImg}`}
                      alt={'photo'}
                    />
                    <h3 className="text-dark mt-3">
                      Matt Brandon
                    </h3>
                  </div>

                  <div className="w-75 ms-auto me-auto mt-5">
                    <p className="text-dark">
                      Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown
                    </p>
                  </div>


                </div>
              </div>
            </div>
          </div>
        </div>
      </section>


    </>
  )
}




