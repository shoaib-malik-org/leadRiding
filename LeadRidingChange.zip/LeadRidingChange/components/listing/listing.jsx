import Image from "next/image"


export function Listing(){
    return (
        <section className="light pt-5">
            <h1 className="text-center crd-heading my-5">
                Some featured vendors
            </h1>
                    <div className="container py-2 mt-5 overflow-none">
                        <div>
                        <article className="vendorList light blue">
                        <img src="/img/crown.png" alt="crown image" className="crownImage position-absolute" />
                            <a className="aImg" href="#">
                                <img className="listImg" src="/repairing.jpg" alt="Image Title" />
                            </a>
                            <div className="listText black">
                                <h1 className="listTitle blue"><a href="#">Asian Electricial Services</a></h1>
                                <div className="small">
                                    <i className="bi bi-geo-alt-fill mr-2 grayColor"></i>New Delhi
                                    <i className="bi bi-geo-alt-fill mr-2 grayColor ml-5"></i>Electrical  Services
                                </div>
                                <div className="listDiv"></div>
                                <div className="listP">Lorem ipsum dolor sit amet consectetur adipisicing elit.Eligendi, fugiat asperiores </div>
                                <ul className="listTabBox">
                                    <li className="listButton v-tagItem"><i className="bi bi-bookmark-check mr-2 "></i>Verified</li>
                                    <li className="listButton c-tagItem ml-3"><i className="bi bi-bookmark-check mr-2 myml" ></i>Get Quote</li>
                                </ul>
                            </div>
                        </article>
                        </div>
                        <div className="overflow-none">
                        <article className="vendorList light blue">
                            <img src="/img/crown.png" alt="crown image" className="crownImage position-absolute" />
                            <a className="aImg" href="#">
                                <img className="listImg" src="/gardening.jpg" alt="Image Title" />
                            </a>
                            <div className="listText  black">
                                <h1 className="listTitle  red"><a href="#">Super gardening</a></h1>
                                <div className="listSubTitle small">
                                    <i className="bi bi-geo-alt-fill mr-2"></i>Kolkata
                                    <i className="bi bi-geo-alt-fill mr-2 grayColor ml-5"></i>Gardening Services
                                </div>
                                <div className="listDiv"></div>
                                <div className="listP">Lorem ipsum dolor sit amet consectetur adipisicing elit. Eligendi, fugiat asperiores .</div>
                                <ul className="listTabBox">
                                    <li className="listButton v-tagItem"><i className="bi bi-bookmark-check mr-2"></i>Verified</li>
                                    <li className="listButton c-tagItem ml-3"><i className="bi bi-bookmark-check mr-2 myml" ></i>Get Quote</li>
                                </ul>
                            </div>
                        </article>
                        </div>
                        <article className="vendorList light blue">
                            <img src="/img/crown.png" alt="crown image" className="crownImage position-absolute" />
                            <a className="aImg" href="#">
                                <img className="listImg" src="/cooling.jpg" alt="Image Title" />
                            </a>
                            <div className="listText black">
                                <h1 className="listTitle green"><a href="#">Vishesh Cooling Solutions</a></h1>
                                <div className="listSubTitle small">
                                    <i className="bi bi-geo-alt-fill mr-2"></i>Mumbai
                                    <i className="bi bi-geo-alt-fill mr-2 grayColor ml-5"></i>AC  Services
                                </div>
                                <div className="listDiv"></div>
                                <div className="listP">Lorem ipsum dolor sit amet consectetur adipisicing elit. Eligendi, fugiat asperiores .</div>
                                <ul className="listTabBox">
                                    <li className="listButton v-tagItem"><i className="bi bi-bookmark-check mr-2"></i>Verified</li>
                                    <li className="listButton c-tagItem ml-3"><i className="bi bi-bookmark-check mr-2 myml" ></i>Get Quote</li>
                                </ul>
                            </div>
                        </article>
                        <article className="vendorList light blue">
                            <img src="/img/crown.png" alt="crown image" className="crownImage position-absolute" />
                            <a className="aImg" href="#">
                                <img className="listImg" src="/waterSolutions.jpeg" alt="Image Title" />
                            </a>
                            <div className="listText black">
                                <h1 className="listTitle yellow"><a href="#">TAP TAP Water Solutions</a></h1>
                                <div className="listSubTitle small">
                                    <i className="bi bi-geo-alt-fill mr-2"></i>Mumbai
                                    <i className="bi bi-geo-alt-fill mr-2 grayColor ml-5"></i>Water  Services
                                </div>
                                <div className="listDiv"></div>
                                <div className="listP">Lorem ipsum dolor sit amet consectetur adipisicing elit. Eligendi.</div>
                                <ul className="listTabBox">
                                    <li className="listButton v-tagItem"><i className="bi bi-bookmark-check mr-2"></i>Verified</li>
                                    <li className="listButton c-tagItem ml-3"><i className="bi bi-bookmark-check mr-2 myml" ></i>Get Quote</li>
                                </ul>
                            </div>
                        </article>
                        <article className="vendorList light blue">
                            <a className="aImg" href="#">
                                <img className="listImg" src="/repairing.jpg" alt="Image Title" />
                            </a>
                            <div className="listText black">
                                <h1 className="listTitle blue"><a href="#">Asian Electricial Services</a></h1>
                                <div className="small">
                                    <i className="bi bi-geo-alt-fill mr-2 grayColor"></i>New Delhi
                                    <i className="bi bi-geo-alt-fill mr-2 grayColor ml-5"></i>Electrical Services
                                </div>
                                <div className="listDiv"></div>
                                <div className="listP">Lorem ipsum dolor sit amet consectetur adipisicing elit.Eligendi, fugiat asperiores </div>
                                <ul className="listTabBox">
                                    <li className="listButton v-tagItem"><i className="bi bi-bookmark-check mr-2"></i>Verified</li>
                                    <li className="listButton c-tagItem ml-3"><i className="bi bi-bookmark-check mr-2 myml" ></i>Get Quote</li>
                                </ul>
                            </div>
                        </article>
                        <article className="vendorList light blue">
                            <a className="aImg" href="#">
                                <img className="listImg" src="/gardening.jpg" alt="Image Title" />
                            </a>
                            <div className="listText  black">
                                <h1 className="listTitle  red"><a href="#">Super gardening</a></h1>
                                <div className="listSubTitle small">
                                    <i className="bi bi-geo-alt-fill mr-2"></i>Kolkata
                                    <i className="bi bi-geo-alt-fill mr-2 grayColor ml-5"></i>Gardening  Services
                                </div>
                                <div className="listDiv"></div>
                                <div className="listP">Lorem ipsum dolor sit amet consectetur adipisicing elit. Eligendi, fugiat asperiores .</div>
                                <ul className="listTabBox">
                                    <li className="listButton v-tagItem"><i className="bi bi-bookmark-check mr-2"></i>Verified</li>
                                    <li className="listButton c-tagItem ml-3"><i className="bi bi-bookmark-check mr-2 myml" ></i>Get Quote</li>
                                </ul>
                            </div>
                        </article>
                        <article className="vendorList light blue">
                            <a className="aImg" href="#">
                                <img className="listImg" src="/cooling.jpg" alt="Image Title" />
                            </a>
                            <div className="listText black">
                                <h1 className="listTitle green"><a href="#">Vishesh Cooling Solutions</a></h1>
                                <div className="listSubTitle small">
                                    <i className="bi bi-geo-alt-fill mr-2"></i>Mumbai
                                    <i className="bi bi-geo-alt-fill mr-2 grayColor ml-5"></i>AC  Services
                                </div>
                                <div className="listDiv"></div>
                                <div className="listP">Lorem ipsum dolor sit amet consectetur adipisicing elit. Eligendi, fugiat asperiores .</div>
                                <ul className="listTabBox">
                                    <li className="listButton v-tagItem"><i className="bi bi-bookmark-check mr-2"></i>Verified</li>
                                    <li className="listButton c-tagItem ml-3"><i className="bi bi-bookmark-check mr-2 myml" ></i>Get Quote</li>
                                </ul>
                            </div>
                        </article>
                        <article className="vendorList light blue">
                            <a className="aImg" href="#">
                                <img className="listImg" src="/waterSolutions.jpeg" alt="Image Title" />
                            </a>
                            <div className="listText black">
                                <h1 className="listTitle yellow"><a href="#">TAP TAP Water Solutions</a></h1>
                                <div className="listSubTitle small">
                                    <i className="bi bi-geo-alt-fill mr-2"></i>Hyderabad
                                    <i className="bi bi-geo-alt-fill mr-2 grayColor ml-5"></i>Water  Services
                                </div>
                                <div className="listDiv"></div>
                                <div className="listP">Lorem ipsum dolor sit amet consectetur adipisicing elit. Eligendi.</div>
                                <ul className="listTabBox">
                                    <li className="listButton v-tagItem"><i className="bi bi-bookmark-check mr-2"></i>Verified</li>
                                    <li className="listButton c-tagItem ml-3"><i className="bi bi-bookmark-check mr-2 myml" ></i>Get Quote</li>
                                </ul>
                            </div>
                        </article>
                    </div>
                </section>
    )
}